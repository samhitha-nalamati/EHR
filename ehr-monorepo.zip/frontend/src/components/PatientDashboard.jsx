export default function PatientDashboard() {
  return <div>Patient Dashboard - view prescriptions and labs</div>;
}