export default function DoctorDashboard() {
  return <div>Doctor Dashboard - upload prescriptions here</div>;
}