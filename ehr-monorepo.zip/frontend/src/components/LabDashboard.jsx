export default function LabDashboard() {
  return <div>Lab Dashboard - upload lab reports</div>;
}