import DoctorDashboard from './components/DoctorDashboard';
import PatientDashboard from './components/PatientDashboard';
import LabDashboard from './components/LabDashboard';

export default function App() {
  return (
    <div>
      <h1>EHR Blockchain Demo</h1>
      <DoctorDashboard />
      <PatientDashboard />
      <LabDashboard />
    </div>
  );
}