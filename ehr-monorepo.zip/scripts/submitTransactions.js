import { AptosClient, TxnBuilderTypes, BCS, FaucetClient } from "@aptos-labs/ts-sdk";

const NODE_URL = process.env.VITE_APTOS_NODE || "https://fullnode.testnet.aptoslabs.com/v1";
const MOVE_ADDRESS = process.env.VITE_MOVE_ADDRESS || "0xYourMoveAddress";

console.log("This script will submit transactions to", MOVE_ADDRESS);

// Example function to submit prescription
export async function doctorUploadPrescription(signer, patientAddr, content) {
  const client = new AptosClient(NODE_URL);
  const payload = {
    type: "entry_function_payload",
    function: `${MOVE_ADDRESS}::ehr::doctor_upload_prescription`,
    type_arguments: [],
    arguments: [patientAddr, Array.from(new TextEncoder().encode(content))]
  };
  const tx = await signer.signAndSubmitTransaction(payload);
  await client.waitForTransaction(tx.hash);
  console.log("Prescription uploaded:", tx.hash);
}